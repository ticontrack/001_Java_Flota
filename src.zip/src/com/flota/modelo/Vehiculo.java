package com.flota.modelo;

public class Vehiculo {
	
	//ATRIBUTOS
	 private String matricula = "";
	 private double cargaMaxima = 3000.0;
	 private double cargaActual = 0.0;
	 private int numCajas = 0;
	
	
	//CONSTRUCTORES
	
	//METODOS
	
	public double getCargaMaxima() {
		return cargaMaxima;
	}

	public void setCargaMaxima(double cargaMaxima) {
		this.cargaMaxima = cargaMaxima;
	}

	public String getMatricula() {
		return matricula;
	}

	public void cargarCaja(Caja caja) {
		this.cargaActual += caja.getPeso();
		this.numCajas ++;
	}
	
	
	public double getCargaActual() {
		return cargaActual;
	}
	
	public int getNumCajas() {
		return numCajas;
	}
	
	
}
