package com.flota.modelo;

public class Caja {

	// ATRIBUTOS  
	private double peso = 10;
	
	//CONSTRUCTORES
	
	
	//MÉTODOS
	
	public double getPeso() {
		return peso;
	}
	
	public void setPeso(double peso) {
		this.peso = peso;
	}
	
	
} //fin clase
