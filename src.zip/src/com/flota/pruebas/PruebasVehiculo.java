package com.flota.pruebas;

import com.flota.modelo.Caja;
import com.flota.modelo.Vehiculo;

public class PruebasVehiculo {

	public static void main(String[] args) {
	   
		
		Vehiculo v1 = new Vehiculo();
		
		v1 = new Vehiculo();
		
		v1.setCargaMaxima(200);
		
		System.out.printf("El camión tiene una capacida de %f kg de carga. %n" , v1.getCargaMaxima());
		
		
		v1.cargarCaja(new Caja());
		v1.cargarCaja(new Caja());
		
		
		
		System.out.printf("carga actual %f  kg y  %d cajas cargadas." 
				, v1.getCargaActual()
				, v1.getNumCajas());
		
		
	}

}
